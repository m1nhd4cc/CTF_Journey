use crate::{𓃠, 𓄁, 𓀤, 𓇽, 𓇃};

pub type 𓇄 = 𓀤<𓇃>;

#[derive(PartialEq)]
pub struct 𓎿;

impl 𓃠 for 𓎿 {}

#[derive(PartialEq)]
pub struct 𓏅<V, A> {
    𓁶: V,
    𓄢: A,
}

#[macro_export]
macro_rules! 𓈝 {
    () => {
        $crate::𓎿
    };
    ($𓁶:ident $($𓄢:ident)*) => {
        $crate::𓏅<$𓁶, 𓈝!($($𓄢)*)>
    };
}
pub trait 𓅄<T> {
    type 𓆏;
}

impl 𓅄<𓎿> for 𓎿 {
    type 𓆏 = 𓎿;
}

impl<V1, A1, V2, A2> 𓅄<𓏅<V2, A2>> for 𓏅<V1, A1>
where
    A1: 𓅄<A2>,
    V1: 𓄁<V2>,
    V2: 𓃠,
    <V1 as 𓄁<V2>>::𓆏: 𓇽<𓇄>,
{
    type 𓆏 = 𓏅<
        <<V1 as 𓄁<V2>>::𓆏 as 𓇽<𓇄>>::𓆏,
        <A1 as 𓅄<A2>>::𓆏,
    >;
}


