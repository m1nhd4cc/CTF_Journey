#![allow(uncommon_codepoints)]
#![allow(non_camel_case_types)]

use std::marker::PhantomData;

use defs::*;
use arr::*;

mod arr;
mod defs;

pub trait 𓃠 {}

impl 𓃠 for 𓂷 {}

#[derive(PartialEq)]
pub struct 𓀤<T> where T: 𓃠 {
    _marker: PhantomData<T>,
}

impl<T: 𓃠> 𓃠 for 𓀤<T> {}

pub trait 𓆇 {}

pub struct 𓅓 {}

impl 𓆇 for 𓅓 {}

pub struct 𓅔 {}

impl 𓆇 for 𓅔 {}

pub trait 𓅮<T: 𓆇> {
    type 𓆏;
}

impl<U, V> 𓅮<𓅓> for (U, V) {
    type 𓆏 = U;
}

impl<U, V> 𓅮<𓅔> for (U, V) {
    type 𓆏 = V;
}

pub trait 𓄁<T: 𓃠>: 𓃠 {
    type 𓆏: 𓃠;
}

impl<T: 𓃠> 𓄁<T> for 𓂷 {
    type 𓆏 = T;
}

impl<T: 𓃠, U: 𓃠> 𓄁<T> for 𓀤<U>
where
    U: 𓄁<T>,
{
    type 𓆏 = 𓀤<U::𓆏>;
}

pub trait 𓀥: 𓃠 {
    type 𓆏: 𓃠;
}

impl 𓀥 for 𓂷 {
    type 𓆏 = 𓂷;
}

impl<T: 𓃠> 𓀥 for 𓀤<T> {
    type 𓆏 = T;
}

pub trait 𓄃<T: 𓃠>: 𓃠 {
    type 𓆏: 𓃠;
}

impl<T: 𓃠> 𓄃<𓂷> for T {
    type 𓆏 = T;
}

impl<T: 𓃠, U: 𓃠, V: 𓃠> 𓄃<𓀤<T>> for U
where
    U: 𓄃<T, 𓆏 = V>,
    V: 𓀥,
{
    type 𓆏 = V::𓆏;
}

pub trait 𓇽<T: 𓃠>: 𓃠 {
    type 𓆏: 𓃠;
}

impl<T: 𓃠> 𓇽<T> for 𓂷 {
    type 𓆏 = 𓂷;
}

impl<T: 𓃠, U: 𓃠, V: 𓃠, W: 𓃠, C: 𓆇> 𓇽<T> for 𓀤<U>
where
    Self: 𓄃<T, 𓆏 = V> + 𓆣<T, 𓆏 = C>,
    V: 𓇽<T>,
    (Self, <V as 𓇽<T>>::𓆏): 𓅮<C, 𓆏 = W>,
{
    type 𓆏 = W;
}

pub trait 𓆃<T: 𓃠> {
    type 𓆏: 𓆇;
}

impl 𓆃<𓂷> for 𓂷 {
    type 𓆏 = 𓅓;
}

impl<T: 𓃠> 𓆃<𓀤<T>> for 𓂷 {
    type 𓆏 = 𓅔;
}

impl<T: 𓃠> 𓆃<𓂷> for 𓀤<T> {
    type 𓆏 = 𓅔;
}

impl<T: 𓃠, U: 𓃠> 𓆃<𓀤<T>> for 𓀤<U>
where
    T: 𓆃<U>,
{
    type 𓆏 = T::𓆏;
}

pub trait 𓆣<T: 𓃠> {
    type 𓆏: 𓆇;
}

impl 𓆣<𓂷> for 𓂷 {
    type 𓆏 = 𓅔;
}

impl<T: 𓃠> 𓆣<𓀤<T>> for 𓂷 {
    type 𓆏 = 𓅓;
}

impl<T: 𓃠> 𓆣<𓂷> for 𓀤<T> {
    type 𓆏 = 𓅔;
}

impl<T: 𓃠, U: 𓃠> 𓆣<𓀤<T>> for 𓀤<U>
where
    U: 𓆣<T>,
{
    type 𓆏 = U::𓆏;
}

pub fn 𓁹<T, U>() where T: PartialEq<U> {
    assert_eq!(std::any::type_name::<T>(), std::any::type_name::<U>());
}

pub fn 𓃈() {
    type 𓌅 = 𓈝![s d c t f 𓉘 w r o n g f l a g 𓉝];

    type 𓂀 = 𓈝![𓃎 𓆽 𓂰 𓃏 𓃑 𓆿 𓆸 𓂴 𓃌 𓃍 𓂷 𓃐 𓂯 𓂱 𓂲 𓂳 𓂵 𓂶 𓃉 𓇀 𓆾 𓂮 𓆼 𓂭 𓃋 𓃊];

    type 𓆟 = 𓈝![𓂮 𓆽 𓂯 𓂰 𓆼 𓃐 𓂳 𓂷 𓇁 𓆸 𓇃 𓃍 𓃉 𓆼 𓇂 𓃑 𓂶 𓂳 𓂶 𓃊 𓇃 𓆸 𓇁 𓃏 𓂱 𓂴];

    𓁹::<<𓌅 as 𓅄<𓂀>>::𓆏, 𓆟>();
}