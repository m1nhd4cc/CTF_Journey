#![allow(unused)]
use crate::{𓀤, 𓄁, 𓄃};

#[derive(PartialEq)]
pub struct 𓂷 {}

pub type 𓂭 = 𓀤<𓂷>;
pub type 𓂮 = 𓀤<𓂭>;
pub type 𓂯 = 𓀤<𓂮>;
pub type 𓂰 = 𓀤<𓂯>;
pub type 𓂱 = 𓀤<𓂰>;
pub type 𓂲 = 𓀤<𓂱>;
pub type 𓂳 = 𓀤<𓂲>;
pub type 𓂴 = 𓀤<𓂳>;
pub type 𓂵 = 𓀤<𓂴>;
pub type 𓂶 = 𓀤<𓂵>;
pub type 𓃉 = 𓀤<𓂶>;
pub type 𓃊 = 𓀤<𓃉>;
pub type 𓃋 = 𓀤<𓃊>;
pub type 𓃌 = 𓀤<𓃋>;
pub type 𓃍 = 𓀤<𓃌>;
pub type 𓃎 = 𓀤<𓃍>;
pub type 𓃏 = 𓀤<𓃎>;
pub type 𓃐 = 𓀤<𓃏>;
pub type 𓃑 = 𓀤<𓃐>;
pub type 𓆸 = 𓀤<𓃑>;
pub type 𓆼 = 𓀤<𓆸>;
pub type 𓆽 = 𓀤<𓆼>;
pub type 𓆾 = 𓀤<𓆽>;
pub type 𓆿 = 𓀤<𓆾>;
pub type 𓇀 = 𓀤<𓆿>;
pub type 𓇁 = 𓀤<𓇀>;
pub type 𓇂 = 𓀤<𓇁>;
pub type 𓇃 = 𓀤<𓇂>;

pub type a = <𓂷 as 𓄁<𓇁>>::𓆏;
pub type b = <𓂭 as 𓄁<𓇁>>::𓆏;
pub type c = <𓂮 as 𓄁<𓇁>>::𓆏;
pub type d = <𓂯 as 𓄃<𓂯>>::𓆏;
pub type e = <𓂰 as 𓄃<𓂯>>::𓆏;
pub type f = <𓂱 as 𓄃<𓂯>>::𓆏;
pub type g = <𓂲 as 𓄃<𓂯>>::𓆏;
pub type h = <𓂳 as 𓄃<𓂯>>::𓆏;
pub type i = <𓂴 as 𓄃<𓂯>>::𓆏;
pub type j = <𓂵 as 𓄃<𓂯>>::𓆏;
pub type k = <𓂶 as 𓄃<𓂯>>::𓆏;
pub type l = <𓃉 as 𓄃<𓂯>>::𓆏;
pub type m = <𓃊 as 𓄃<𓂯>>::𓆏;
pub type n = <𓃋 as 𓄃<𓂯>>::𓆏;
pub type o = <𓃌 as 𓄃<𓂯>>::𓆏;
pub type p = <𓃍 as 𓄃<𓂯>>::𓆏;
pub type q = <𓃎 as 𓄃<𓂯>>::𓆏;
pub type r = <𓃏 as 𓄃<𓂯>>::𓆏;
pub type s = <𓃐 as 𓄃<𓂯>>::𓆏;
pub type t = <𓃑 as 𓄃<𓂯>>::𓆏;
pub type u = <𓆸 as 𓄃<𓂯>>::𓆏;
pub type v = <𓆼 as 𓄃<𓂯>>::𓆏;
pub type w = <𓆽 as 𓄃<𓂯>>::𓆏;
pub type x = <𓆾 as 𓄃<𓂯>>::𓆏;
pub type y = <𓆿 as 𓄃<𓂯>>::𓆏;
pub type z = <𓇀 as 𓄃<𓂯>>::𓆏;
pub type 𓉘 = <𓇁 as 𓄃<𓂯>>::𓆏;
pub type 𓉶 = <𓇂 as 𓄃<𓂯>>::𓆏;
pub type 𓉝 = <𓇃 as 𓄃<𓂯>>::𓆏;