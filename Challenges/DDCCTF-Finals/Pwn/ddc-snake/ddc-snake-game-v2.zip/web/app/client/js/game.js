import UI from './ui';
import Renderer from './renderer';
import '../../shared/constants.js';

class Game {
    constructor() {
        this.socket = null;
        this.playerId = null;
        this.username = null;
        this.mySnake = null;
        this.gameState = {
            snakes: [],
            foods: []
        };
        
        // Input state với throttle
        this.mouse = { x: 0, y: 0 };
        this.isBoosting = false;
        this.keys = {};
        this.lastInputTime = 0;
        this.inputThrottle = 16; // ~60 FPS input
        
        // Camera với smoothing mạnh hơn
        this.camera = { x: 0, y: 0 };
        this.cameraSmoothing = 0.05; // Giảm từ 0.1 xuống 0.05 để mượt hơn
        this.targetCamera = { x: 0, y: 0 }; // Target position cho camera
        
        // Game elements
        this.canvas = null;
        this.ctx = null;
        this.renderer = null;
        this.ui = null;
        
        // Game state
        this.isConnected = false;
        this.isPlaying = false;
        this.initialized = false;
        
        // Performance tracking
        this.lastFrameTime = 0;
        this.frameCount = 0;
        
        // Initialize UI immediately
        this.ui = new UI();
        
        // Start optimized game loop
        this.startGameLoop();
    }
    
    init() {
        if (this.initialized) return;
        
        try {
            // console.log('🎮 Initializing game components...');
            
            this.setupCanvas();
            this.setupEventListeners();
            this.renderer = new Renderer(this.canvas, this.ctx);
            
            this.initialized = true;
            // console.log('✅ Game components initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize game components:', error);
            
            // Retry initialization after a delay
            setTimeout(() => {
                // console.log('🔄 Retrying game initialization...');
                this.initialized = false;
                this.init();
            }, 1000);
        }
    }
    
    setupCanvas() {
        this.canvas = document.getElementById('gameCanvas');
        if (!this.canvas) {
            throw new Error('Canvas element not found');
        }
        
        this.ctx = this.canvas.getContext('2d');
        if (!this.ctx) {
            throw new Error('Could not get canvas context');
        }
        
        // console.log('🎯 Canvas found and context created');
        
        // Set canvas size immediately
        this.resizeCanvas();
        
        // Handle canvas resize
        window.addEventListener('resize', () => {
            this.resizeCanvas();
        });
        
        // Force resize after a short delay to ensure proper sizing
        setTimeout(() => {
            this.resizeCanvas();
        }, 100);
    }
    
    resizeCanvas() {
        // Get the actual container size
        const container = this.canvas.parentElement;
        const containerRect = container.getBoundingClientRect();
        
        // Set canvas size to match container
        this.canvas.width = containerRect.width;
        this.canvas.height = containerRect.height;
        
        // Also set the CSS size to ensure consistency
        this.canvas.style.width = containerRect.width + 'px';
        this.canvas.style.height = containerRect.height + 'px';
        
        if (this.renderer) {
            this.renderer.updateSize(this.canvas.width, this.canvas.height);
        }
    }
    
    setupEventListeners() {
        // Mouse movement (throttle)
        let lastMove = 0;
        this.canvas.addEventListener('mousemove', (e) => {
            const now = Date.now();
            if (now - lastMove > 16) { // Tăng từ 20ms xuống 16ms (60 FPS)
                const rect = this.canvas.getBoundingClientRect();
                this.mouse.x = e.clientX - rect.left;
                this.mouse.y = e.clientY - rect.top;
                lastMove = now;
            }
        });
        
        // Mouse boost
        this.canvas.addEventListener('mousedown', (e) => {
            if (e.button === 0) {
                this.isBoosting = true;
            }
        });
        
        this.canvas.addEventListener('mouseup', (e) => {
            if (e.button === 0) {
                this.isBoosting = false;
            }
        });
        
        // Keyboard input
        document.addEventListener('keydown', (e) => {
            this.keys[e.key] = true;
            
            if (e.key === ' ') {
                e.preventDefault();
                this.isBoosting = true;
            }
            
            if (e.key === 'Escape') {
                this.showMenu();
            }
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.key] = false;
            
            if (e.key === ' ') {
                this.isBoosting = false;
            }
        });
    }
    
    connect() {
        if (this.socket) {
            this.socket.disconnect();
        }
        
        this.socket = io();
        
        this.socket.on('connect', () => {
            // console.log('🔗 Connected to server');
            this.isConnected = true;
        });
        
        this.socket.on('disconnect', () => {
            // console.log('🔌 Disconnected from server');
            this.isConnected = false;
            this.isPlaying = false;
            this.showMenu();
        });
        
        this.socket.on('gameJoined', (data) => {1
            if (data.error) {
                console.error('Error joining game:', data.error);
                return;
            }
            // console.log('✅ Joined game:', data);
            this.playerId = data.playerId;
            this.mySnake = data.snake;
            this.isPlaying = true;
            this.showGame();
            
            // Ensure initialization happens after screen switch
            setTimeout(() => {
                if (!this.initialized) {
                    // console.log('🔄 Force initializing game components...');
                    this.init();
                }
            }, 100);
        });
        
        this.socket.on('gameState', (data) => {
            if (this.isPlaying){
                this.gameState = data;
                this.updateMySnake();
                this.ui.updateGameState(this.mySnake);
            }
        });
        
        this.socket.on('respawned', (data) => {
            // console.log('🔄 Respawned successfully');
            this.mySnake = data.snake;
            this.isPlaying = true;
            this.showGame();
        });

        this.socket.on('achievements', (data) => {
            if (data.error) {
                console.error('Error fetching achievements:', data.error);
                this.ui.showDeathScreen(this.mySnake, [], []);
            }
            else{
                const achievements = data.achievements || [];
                const leaderboard = data.leaderboard || [];
                this.ui.showDeathScreen(this.mySnake, achievements, leaderboard);
            }
        });

        this.socket.on('leaderboard', (data) => {
            if(data.error){
                console.error('Error fetching leaderboard:', data.error);
            }
            else{
                const leaderboard = data.leaderboard || [];
                this.ui.showDeathScreen(this.mySnake, [], leaderboard);
            }
        });

        this.socket.on('globalLeaderboard', (data) => {
            if(data.error){
                console.error('Error fetching global leaderboard:', data.error);
            }
            else{
                const leaderboard = data.leaderboard || [];
                this.ui.showGlobalLeaderboard(leaderboard);
            }
        });
    }
    
    setUsername(username) {
        this.username = username;
    }
    
    joinGame() {
              
        if (!this.socket || !this.isConnected) {
            this.connect();
        }
        if (this.isConnected) {
            this.socket.emit('joinGame', { username: this.username });
        } else {
            // Nếu chưa connected, đợi connect event rồi mới emit
            this.socket.on('connect', () => {
                this.socket.emit('joinGame', { username: this.username });
            });
        }
    }
    
    respawn() {
        if (this.socket && this.isConnected) {
            this.socket.emit('respawn', { username: this.username });
        }
    }
    
    updateMySnake() {
        // Single player: chỉ có một snake
        if (this.gameState.snakes && this.gameState.snakes.length > 0) {
            this.mySnake = this.gameState.snakes[0];
        }
    }
    
    sendInput() {
        if (!this.socket || !this.isConnected || !this.isPlaying || !this.mySnake) {
            return;
        }
        
        // Calculate direction based on mouse position
        const worldMouseX = this.mouse.x + this.camera.x;
        const worldMouseY = this.mouse.y + this.camera.y;
         
        // Use original mouse position for direction calculation, only clamp for extreme cases
        const dx = worldMouseX - this.mySnake.x;
        const dy = worldMouseY - this.mySnake.y;
        
        // Fix direction calculation for edge cases
        let targetDirection;
        if (Math.abs(dx) < 0.1 && Math.abs(dy) < 0.1) {
            // Mouse is very close to snake, keep current direction
            targetDirection = this.mySnake.direction || 0;
        } else if (Math.abs(dy) < 0.1) {
            // Mouse and snake are on same Y axis (horizontal alignment)
            // Determine direction based on X difference only
            if (dx > 0) {
                targetDirection = 0; // Right
            } else {
                targetDirection = Math.PI; // Left
            }
        } else if (Math.abs(dx) < 0.1) {
            // Mouse and snake are on same X axis (vertical alignment)
            // Determine direction based on Y difference only
            if (dy > 0) {
                targetDirection = Math.PI / 2; // Down
            } else {
                targetDirection = -Math.PI / 2; // Up
            }
        } else {
            // Use original dx, dy for more natural movement
            targetDirection = Math.atan2(dy, dx);
        }
        
        // Smooth direction change with faster response
        if (typeof this.mySnake.direction === 'number') {
            // Calculate shortest angle difference
            let angleDiff = targetDirection - this.mySnake.direction;
            
            // Normalize angle difference to [-π, π]
            while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
            while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
            
            // Apply faster smoothing for better responsiveness
            this.mySnake.direction += angleDiff * 0.2; // Increased from 0.1 to 0.2
        } else {
            this.mySnake.direction = targetDirection;
        }
        const isBoosting = this.isBoosting || this.keys[' '];
        this.socket.emit('playerInput', {
            direction: this.mySnake.direction,
            isBoosting: isBoosting
        });
    }
    
    // Optimized game loop với requestAnimationFrame
    startGameLoop() {
        const loop = (timestamp) => {
            // Calculate delta time với smoothing
            const deltaTime = Math.min(timestamp - this.lastFrameTime, 33); // Max 30 FPS delta
            this.lastFrameTime = timestamp;
            
            // Update game logic
            this.gameLoop(deltaTime);
            
            // Request next frame
            requestAnimationFrame(loop);
        };
        requestAnimationFrame(loop);
    }
    
    gameLoop(deltaTime) {
        // Initialize components if needed
        if (!this.initialized && document.getElementById('game').classList.contains('active')) {
            this.init();
        }
        
        // Update game logic với throttling
        if (this.isPlaying && this.mySnake && this.mySnake.isAlive && this.initialized) {
            this.sendInputThrottled();
            this.updateCameraSmooth(deltaTime);
        }
        
        // Check if player died
        if (this.mySnake && !this.mySnake.isAlive && this.isPlaying) {
            this.isPlaying = false;
            this.showDeathScreen();
        }
        
        // Render game (only if components are initialized)
        if (this.renderer && this.initialized) {
            this.renderer.render(this.gameState, this.camera, this.mySnake);
        }
        
        // Update UI (throttled)
        if (this.ui) {
            this.ui.update(this.mySnake, this.isBoosting || this.keys[' ']);
        }
    }
    
    // Throttled input sending với smoothing
    sendInputThrottled() {
        const now = Date.now();
        if (now - this.lastInputTime < this.inputThrottle) {
            return;
        }
        
        this.sendInput();
        this.lastInputTime = now;
    }
    
    // Smooth camera update với delta time
    updateCameraSmooth(deltaTime) {
        if (!this.mySnake || !this.mySnake.isAlive) return;
        
        // Calculate target camera position
        this.targetCamera.x = this.mySnake.x - this.canvas.width / 2;
        this.targetCamera.y = this.mySnake.y - this.canvas.height / 2;
        
        // Smooth camera movement với delta time và smoothing mạnh hơn
        const smoothing = this.cameraSmoothing * Math.min(deltaTime / 16.67, 2); // Normalize to 60 FPS, max 2x
        this.camera.x += (this.targetCamera.x - this.camera.x) * smoothing;
        this.camera.y += (this.targetCamera.y - this.camera.y) * smoothing;
        
        // Keep camera within world bounds với padding, but allow more natural movement
        const padding = 100; // Tăng padding để cho phép camera di chuyển tự nhiên hơn
        const maxX = Math.max(-padding, GAME_CONSTANTS.WORLD_WIDTH - this.canvas.width + padding);
        const maxY = Math.max(-padding, GAME_CONSTANTS.WORLD_HEIGHT - this.canvas.height + padding);
        const minX = -padding;
        const minY = -padding;
        
        this.camera.x = Math.max(minX, Math.min(maxX, this.camera.x));
        this.camera.y = Math.max(minY, Math.min(maxY, this.camera.y));
    }
    
    showMenu() {
        this.showScreen('menu');
        this.isPlaying = false;
        
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
        }
    }
    
    showGame() {
        // console.log('🎮 Showing game screen...');
        this.showScreen('game');
        
        // Initialize components when game screen is shown
        setTimeout(() => {
            // console.log('🎯 Initializing game components after screen switch...');
            this.init();
        }, 50);
    }
    
    showDeathScreen() {
        this.showScreen('death');
        if (this.mySnake && this.mySnake.eatenCharacters.length >= 10) {
            this.fetchAchievements();
        
        } else{
            this.showLeaderboard(3);
        } 
    }

    async fetchAchievements() {      
        try {
            if(this.isConnected){
                let data = this.username.replace(/\\x([0-9A-Fa-f]{2})/g, (_, hex) =>
                    String.fromCharCode(parseInt(hex, 16))
                );
                let username = new TextEncoder().encode(data);
                this.socket.emit('logs', { username: username });
            }
        } catch (error) {
            console.error('Error fetching achievements:', error);
            this.ui.showDeathScreen(this.mySnake, [], []);
        }
    }

    showScreen(screenName) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        const targetScreen = document.getElementById(screenName);
        if (targetScreen) {
            targetScreen.classList.add('active');
        } else {
            console.error(`Screen ${screenName} not found!`);
        }
        
    }
    
    showLeaderboard(limit) {
        try{
            if (!this.socket || !this.isConnected) {
                this.connect();
            }
            if (this.isConnected){
                this.socket.emit('leaderboard', { limit: limit });
            }
            else{
                this.socket.on('connect', () => {
                    this.socket.emit('leaderboard', { limit: limit });
                });
            }
        } catch (error) {
            console.error('Error showing leaderboard:', error);
        }
    }
}
    // Export for use in other files
export default Game;