class Renderer {
    constructor(canvas, ctx) {
        this.canvas = canvas;
        this.ctx = ctx;
        this.width = canvas.width;
        this.height = canvas.height;
        
        // Performance optimizations
        this.lastRenderTime = 0;
        this.renderThrottle = 16; // ~60 FPS render
    }
    
    updateSize(width, height) {
        this.width = width;
        this.height = height;
    }
    
    // Optimized render với visual effects đẹp
    render(gameState, camera, mySnake) {
        const now = Date.now();
        if (now - this.lastRenderTime < this.renderThrottle) {
            return;
        }
        this.lastRenderTime = now;
        
        // Clear canvas với background đơn giản
        // this.ctx.fillStyle = '#2c3e50';
        // this.ctx.fillRect(0, 0, this.width, this.height);
        this.drawBackground(camera);
        // Draw world boundaries
        this.drawWorldBoundaries(camera);
        
        // Safety check for game state
        if (!gameState) {
            // Draw "No Game State" message
            this.ctx.fillStyle = '#fff';
            this.ctx.font = '24px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText('No Game State', this.width / 2, this.height / 2);
            return;
        }
        
        // Draw foods với culling
        if (gameState.foods && Array.isArray(gameState.foods)) {
            this.drawFoods(gameState.foods, camera);
        }
        

        // Draw my snake on top
        if (mySnake && mySnake.isAlive) {
            this.drawSnake(mySnake, camera, true);
        }
    }
    
    drawBackground(camera) {
        // Gradient background chỉ trong viewport thực tế
        // Tạo gradient theo toạ độ thế giới
        const gradient = this.ctx.createLinearGradient(0, 0, this.width, this.height);
        gradient.addColorStop(0, '#2c3e50');
        gradient.addColorStop(1, '#3498db');
        this.ctx.save();
        this.ctx.beginPath();
        this.ctx.rect(0, 0, this.width, this.height);
        this.ctx.clip();
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.width, this.height);
        this.ctx.restore();
    }
    

    drawWorldBoundaries(camera) {
        this.ctx.strokeStyle = '#ff6b6b';
        this.ctx.lineWidth = 4;
        this.ctx.setLineDash([10, 10]);
        
        const padding = 50; // Thêm padding để giảm sensitivity
        
        // Top boundary
        if (camera.y <= padding) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, -camera.y);
            this.ctx.lineTo(this.width, -camera.y);
            this.ctx.stroke();
        }
        
        // Bottom boundary
        if (camera.y + this.height >= GAME_CONSTANTS.WORLD_HEIGHT - padding) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, GAME_CONSTANTS.WORLD_HEIGHT - camera.y);
            this.ctx.lineTo(this.width, GAME_CONSTANTS.WORLD_HEIGHT - camera.y);
            this.ctx.stroke();
        }
        
        // Left boundary
        if (camera.x <= padding) {
            this.ctx.beginPath();
            this.ctx.moveTo(-camera.x, 0);
            this.ctx.lineTo(-camera.x, this.height);
            this.ctx.stroke();
        }
        
        // Right boundary
        if (camera.x + this.width >= GAME_CONSTANTS.WORLD_WIDTH - padding) {
            this.ctx.beginPath();
            this.ctx.moveTo(GAME_CONSTANTS.WORLD_WIDTH - camera.x, 0);
            this.ctx.lineTo(GAME_CONSTANTS.WORLD_WIDTH - camera.x, this.height);
            this.ctx.stroke();
        }
        
        this.ctx.setLineDash([]);
    }
    
    drawFoods(foods, camera) {
        foods.forEach(food => {
            this.drawFood(food, camera);
        });
    }
    
    drawFood(food, camera) {
        const screenX = food.x - camera.x;
        const screenY = food.y - camera.y;
        
        // Skip if off screen
        if (screenX < -food.size || screenX > this.width + food.size ||
            screenY < -food.size || screenY > this.height + food.size) {
            return;
        }
        
        // Draw food circle
        this.ctx.fillStyle = food.color;
        this.ctx.beginPath();
        this.ctx.arc(screenX, screenY, food.size, 0, Math.PI * 2);
        this.ctx.fill();
        
        // Draw food outline
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        
        // Draw character
        this.ctx.fillStyle = '#fff';
        this.ctx.font = `bold ${Math.floor(food.size * 1.2)}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(food.char, screenX, screenY);
    }
    
    drawSnake(snake, camera, isMySnake) {
        if (!snake.isAlive || !snake.segments || snake.segments.length === 0) {
            return;
        }
        
        // Draw snake body segments với màu từng segment
        for (let i = snake.segments.length - 1; i >= 0; i--) {
            const segment = snake.segments[i];
            // Sử dụng màu của snake cho tất cả segments
            this.drawSnakeSegment(segment, camera, snake.color, i === 0, isMySnake);
        }

    }
    
    drawSnakeSegment(segment, camera, color, isHead, isMySnake) {
        const screenX = segment.x - camera.x;
        const screenY = segment.y - camera.y;
        
        // Use constant segment size instead of server data
        const size = GAME_CONSTANTS.SEGMENT_SIZE;
        
        // Skip if off screen
        if (screenX < -size || screenX > this.width + size ||
            screenY < -size || screenY > this.height + size) {
            return;
        }
        
        // Draw segment body với màu riêng và viền khác nhau cho my snake
        this.ctx.fillStyle = color;
        this.ctx.beginPath();
        this.ctx.arc(screenX, screenY, size, 0, Math.PI * 2); // Sử dụng size thực tế
        this.ctx.fill();
        
        // Draw border với style khác nhau cho my snake và other snakes
        if (isMySnake) {
            // My snake: viền trắng đậm hơn
            this.ctx.strokeStyle = '#ffffff';
            this.ctx.lineWidth = 2;
        } else {
            // Other snakes: viền trắng mờ hơn
            this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
            this.ctx.lineWidth = 2;
        }
        this.ctx.stroke();
        
        // Draw head details (chỉ cho đầu)
        if (isHead) {
            // Draw eyes
            const eyeSize = size * 0.15;
            const eyeOffset = size * 0.4;
            
            this.ctx.fillStyle = '#fff';
            this.ctx.beginPath();
            this.ctx.arc(screenX - eyeOffset, screenY - eyeOffset, eyeSize, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.beginPath();
            this.ctx.arc(screenX + eyeOffset, screenY - eyeOffset, eyeSize, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Draw pupils
            this.ctx.fillStyle = '#000';
            this.ctx.beginPath();
            this.ctx.arc(screenX - eyeOffset, screenY - eyeOffset, eyeSize * 0.6, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.beginPath();
            this.ctx.arc(screenX + eyeOffset, screenY - eyeOffset, eyeSize * 0.6, 0, Math.PI * 2);
            this.ctx.fill();
        }
    }
    
    
}

// Export for use in other files
export default Renderer; 