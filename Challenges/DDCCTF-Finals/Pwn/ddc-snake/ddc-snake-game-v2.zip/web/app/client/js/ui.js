class UI {
    constructor() {
        this.elements = {
            playerName: document.getElementById('playerName'),
            playerLength: document.getElementById('playerLength'),
            eatenString: document.getElementById('eatenString'),
            boostIndicator: document.getElementById('boostIndicator'),
            letterBoxC: document.querySelector('.letter-box[data-letter="C"]'),
            letterBoxB: document.querySelector('.letter-box[data-letter="B"]'),
            letterBoxJ: document.querySelector('.letter-box[data-letter="J"]'),
            letterBoxS: document.querySelector('.letter-box[data-letter="S"]')
        };
        
        this.lastMySnake = null;
    }
    
    updateGameState(mySnake) {
        this.lastMySnake = mySnake;
        
        // Update player info
        if (mySnake) {
            this.updatePlayerInfo(mySnake);
        }
    }
    
    updatePlayerInfo(snake) {
        if (!snake) return;
        
        // Update player name/username
        if (this.elements.playerName && snake.username) {
            this.elements.playerName.textContent = snake.username;
        }
        
        // Update player length
        if (this.elements.playerLength) {
            this.elements.playerLength.textContent = (snake.length - GAME_CONSTANTS.INITIAL_LENGTH) || 0;
        }
        
        // Update CBJS collection highlights
        if (snake.letterCounts) {
            // Update C letter box
            if (this.elements.letterBoxC) {
                if (snake.letterCounts.C > 0) {
                    this.elements.letterBoxC.classList.add('collected');
                } else {
                    this.elements.letterBoxC.classList.remove('collected');
                }
            }
            
            // Update B letter box
            if (this.elements.letterBoxB) {
                if (snake.letterCounts.B > 0) {
                    this.elements.letterBoxB.classList.add('collected');
                } else {
                    this.elements.letterBoxB.classList.remove('collected');
                }
            }
            
            // Update J letter box
            if (this.elements.letterBoxJ) {
                if (snake.letterCounts.J > 0) {
                    this.elements.letterBoxJ.classList.add('collected');
                } else {
                    this.elements.letterBoxJ.classList.remove('collected');
                }
            }
            
            // Update S letter box
            if (this.elements.letterBoxS) {
                if (snake.letterCounts.S > 0) {
                    this.elements.letterBoxS.classList.add('collected');
                } else {
                    this.elements.letterBoxS.classList.remove('collected');
                }
            }
        }
        
        // Update eaten string
        if (this.elements.eatenString && snake.eatenCharacters) {
            this.elements.eatenString.textContent = snake.eatenCharacters.join('');
        }
    }
    
    
    update(mySnake, isBoosting) {
        // Update boost indicator
        if (this.elements.boostIndicator) {
            if (isBoosting && mySnake && mySnake.isAlive) {
                this.elements.boostIndicator.classList.add('active');
            } else {
                this.elements.boostIndicator.classList.remove('active');
            }
        }
        
        // Update player info if we have a snake
        if (mySnake) {
            this.updatePlayerInfo(mySnake);
        }
    }
    
    showDeathScreen(snake, achievements = [], leaderboard = []) {
        if (!snake) return;
        
        // Display achievements
        this.displayAchievements(achievements);
        
        // Display leaderboard
        this.displayLeaderboard(leaderboard);
    }
    
    displayLeaderboard(leaderboard) {
        const leaderboardList = document.getElementById('leaderboardList');
        const yourScoreElement = document.getElementById('yourScore');
        if (!leaderboardList) return;
        
        // Clear previous leaderboard
        leaderboardList.innerHTML = '';
        let myUsernameExists = false;

        if (leaderboard.length === 0) {
            // Show default loading state
            for (let i = 1; i <= 3; i++) {
                const item = document.createElement('div');
                item.className = 'leaderboard-item';
                item.innerHTML = `
                    <span class="rank">${i}</span>
                    <span class="player-name">Loading...</span>
                    <span class="score">0</span>
                `;
                leaderboardList.appendChild(item);
            }
            return;
        }
        
        // Display leaderboard data
        leaderboard.forEach((player, index) => {
            const item = document.createElement('div');
            item.className = 'leaderboard-item';
            item.innerHTML = `
                <span class="rank">${index + 1}</span>
                <span class="player-name">${player.name || 'Unknown'}</span>
                <span class="score">${player.score || 0}</span>
            `;
            leaderboardList.appendChild(item);
            if(player.name === this.lastMySnake.username) {
                myUsernameExists = true;
            }
        });
        
        // Show player's own score if available
        if (this.lastMySnake && this.lastMySnake.eatenCharacters) {
            if (myUsernameExists == false) {
                if (yourScoreElement) {
                    yourScoreElement.style.display = 'flex';
                    yourScoreElement.innerHTML = `
                        <span class="player-name">${this.lastMySnake.username}</span>
                        <span class="score">${this.lastMySnake.eatenCharacters.length}</span>
                    `;
                }
            }
        }
    }

    displayAchievements(achievements) {
        const achievementsContainer = document.getElementById('achievementsContainer');
        if (!achievementsContainer) return;
        
        // Clear previous achievements
        achievementsContainer.innerHTML = '';
        
        if (achievements.length === 0) {
            achievementsContainer.innerHTML = '<p class="no-achievements">No achievements unlocked this game</p>';
            return;
        }
        
        // Create achievements title
        const title = document.createElement('h3');
        title.className = 'achievements-title';
        title.textContent = 'Achievements Unlocked!';
        achievementsContainer.appendChild(title);
        
        // Create achievements list
        const achievementsList = document.createElement('div');
        achievementsList.className = 'achievements-list';
        
        achievements.forEach((achievement, index) => {
            const achievementItem = document.createElement('div');
            achievementItem.className = 'achievement-item';
            achievementItem.style.animationDelay = `${index * 0.1}s`;
            
            achievementItem.innerHTML = `
                <div class="achievement-icon">${achievement.icon}</div>
                <div class="achievement-content">
                    <div class="achievement-type">${achievement.type}</div>
                    <div class="achievement-description">${achievement.description}</div>
                </div>
            `;
            
            achievementsList.appendChild(achievementItem);
        });
        
        achievementsContainer.appendChild(achievementsList);
    }

    showGlobalLeaderboard(leaderboard) {
        const leaderboardList = document.getElementById('globalLeaderboardList');
        if (leaderboardList) {
            leaderboardList.innerHTML = '';
            
            leaderboard.forEach((player, index) => {
                const item = document.createElement('div');
                item.className = 'leaderboard-item';
                item.innerHTML = `
                    <span class="rank">${index + 1}</span>
                    <span class="player-name">${player.name}</span>
                    <span class="score">${player.score}</span>
                `;
                leaderboardList.appendChild(item);
            });
        }
    }
}

// Export for use in other files
export default UI; 