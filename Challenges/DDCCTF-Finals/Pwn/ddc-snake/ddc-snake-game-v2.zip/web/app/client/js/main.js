import Game from './game';
import UI from './ui';
import Renderer from './renderer';
import '../../shared/constants.js';

// Global game instance
let game = null;
// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Wait for all resources to load
    window.addEventListener('load', function() {
        
        // Small delay to ensure everything is ready
        setTimeout(() => {
            initializeGame();
        }, 50);
    });
    
    // Fallback initialization if window.load doesn't fire
    setTimeout(() => {
        if (!game) {
            initializeGame();
        }
    }, 500);
});

function initializeGame() {
    if (game) {
        return;
    }
    
    try {
        // Initialize game
        game = new Game();
        
        // Setup menu event listeners
        setupMenuEvents();
        
        // Setup death screen events
        setupDeathScreenEvents();
        
        // Hide loading screen and show menu
        setTimeout(() => {
            document.getElementById('loading').classList.remove('active');
            document.getElementById('menu').classList.add('active');
            
        }, 500);
        
        // Export for debugging
        window.game = game;
        
    } catch (error) {
        console.error('Failed to initialize game:', error);
        
        // Show error message on loading screen
        const loadingContent = document.querySelector('.loading-content');
        if (loadingContent) {
            loadingContent.innerHTML = `
                <div class="loading-spinner"></div>
                <h2>Loading Failed</h2>
                <p>Retrying in 3 seconds...</p>
            `;
        }
        
        // Retry after a short delay
        setTimeout(() => {
            game = null;
            
            // Reset loading screen
            const loadingContent = document.querySelector('.loading-content');
            if (loadingContent) {
                loadingContent.innerHTML = `
                    <div class="loading-spinner"></div>
                    <h2>Loading DDC Snake Game...</h2>
                    <p>Initializing game world...</p>
                `;
            }
            
            initializeGame();
        }, 3000);
    }
}

function setupMenuEvents() {
    const playButton = document.getElementById('playButton');
    const leaderboardButton = document.getElementById('leaderboardButton');
    const closeLeaderboardButton = document.getElementById('closeLeaderboardButton');
    
    if (playButton) {
        playButton.addEventListener('click', startGame);
    }
    
    if (leaderboardButton) {
        leaderboardButton.addEventListener('click', showLeaderboard);
    }
    
    if (closeLeaderboardButton) {
        closeLeaderboardButton.addEventListener('click', hideLeaderboard);
    }
}

function showLeaderboard() {
    // Hide menu and show leaderboard modal
    document.getElementById('menu').classList.remove('active');
    document.getElementById('leaderboardModal').classList.add('active');
    
    // Load leaderboard data
    loadGlobalLeaderboard();
}

function hideLeaderboard() {
    // Hide leaderboard modal and show menu
    document.getElementById('leaderboardModal').classList.remove('active');
    document.getElementById('menu').classList.add('active');
}

function loadGlobalLeaderboard() {
    // For now, show sample data
    if (game){
        game.showLeaderboard(10);
    }
}

function setupDeathScreenEvents() {
    const respawnButton = document.getElementById('respawnButton');
    const menuButton = document.getElementById('menuButton');
    
    if (respawnButton) {
        respawnButton.addEventListener('click', function() {
            if (game) {
                game.respawn();
            }
        });
    }
    
    if (menuButton) {
        menuButton.addEventListener('click', function() {
            if (game) {
                game.showMenu();
            }
        });
    }
}

function startGame() {
    const usernameInput = document.getElementById('usernameInput');
    const username = usernameInput ? usernameInput.value.trim() : '';
    
    // Validate username
    if (!username) {
        alert('Please enter a username to start the game!');
        if (usernameInput) {
            usernameInput.focus();
        }
        return;
    }
    
    if (username.length < 2) {
        alert('Username must be at least 2 characters long!');
        if (usernameInput) {
            usernameInput.focus();
        }
        return;
    }
    
    if (username.length > 30) {
        alert('Username must be 30 characters or less!');
        if (usernameInput) {
            usernameInput.focus();
        }
        return;
    }
    
    if (game) {
        game.setUsername(username);
        game.joinGame();
    }
}


// Prevent context menu on canvas
document.addEventListener('contextmenu', function(e) {
    if (e.target.tagName === 'CANVAS') {
        e.preventDefault();
    }
});

// Prevent default drag behavior
document.addEventListener('dragstart', function(e) {
    e.preventDefault();
});

// Prevent text selection during gameplay
document.addEventListener('selectstart', function(e) {
    if (e.target.tagName === 'CANVAS') {
        e.preventDefault();
    }
});

// Export for debugging
window.startGame = startGame;
window.game = game; 