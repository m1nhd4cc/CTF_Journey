// Game constants shared between client and server
const GAME_CONSTANTS = {
    // World settings
    WORLD_WIDTH: 1920,
    WORLD_HEIGHT: 1080,
    
    // Snake settings
    SNAKE_SPEED: 120, // pixels per second
    BOOST_SPEED: 180, // pixels per second
    INITIAL_LENGTH: 5,
    SEGMENT_SIZE: 12,
    SEGMENT_SPACING: 6,
    
    // Food settings
    FOOD_COUNT: 50,
    FOOD_SIZE: 12,
    FOOD_COLORS: ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#dda0dd', '#98d8c8'],
    
    // CBJS Characters
    TARGET_LETTERS: ['C', 'B', 'J', 'S'],
    CBJS_SPAWN_RATE: 0.15, // 15% chance for CBJS letters
    CBJS_COLORS: {
        'C': '#ff4757',
        'B': '#3742fa',
        'J': '#2ed573',
        'S': '#ffa502'
    },
    
    // Network settings
    TICK_RATE: 1000 / 30, // 30 FPS
    
    // Colors
    SNAKE_COLORS: [
        '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', 
        '#ffeaa7', '#dda0dd', '#98d8c8', '#f093fb',
        '#ff9a9e', '#a8edea', '#d299c2', '#fad0c4'
    ],
    
    // Achievements mapping (matches C server output)
    ACHIEVEMENTS: [
        {
            type: 'Beginner',
            description: 'Reached 10 points!',
            icon: '🗡️'
        },
        {
            type: 'Hunter',
            description: 'Reached 20 points!',
            icon: '🏹'
        },
        {
            type: 'Master',
            description: 'Reached 50 points!',
            icon: '⚔️'
        },
        {
            type: 'First CBJS',
            description: 'Collected 1 CBJS set!',
            icon: '🎖️'
        },
        {
            type: 'CBJS Collector',
            description: 'Collected 2 CBJS sets!',
            icon: '🥇'
        },
        {
            type: 'CBJS Master',
            description: 'Collected 5 CBJS sets!',
            icon: '🏆'
        }
    ]
};

// Export for Node.js
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GAME_CONSTANTS;
}

// Export for browser
if (typeof window !== 'undefined') {
    window.GAME_CONSTANTS = GAME_CONSTANTS;
} 