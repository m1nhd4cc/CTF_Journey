const CONSTANTS = require('../../shared/constants');

class Snake {
    constructor(id, x, y, username) {
        this.id = id;
        this.username = username;
        this.x = x;
        this.y = y;
        this.direction = Math.random() * Math.PI * 2;
        this.speed = CONSTANTS.SNAKE_SPEED;
        this.isBoosting = false;
        this.isAlive = true;
        this.length = CONSTANTS.INITIAL_LENGTH;
        this.color = CONSTANTS.SNAKE_COLORS[Math.floor(Math.random() * CONSTANTS.SNAKE_COLORS.length)];   
        // Body segments
        this.segments = [];
        this.initializeSegments();
        
        // CBJS character collection
        this.eatenCharacters = [];
        this.letterCounts = { C: 0, B: 0, J: 0, S: 0 };
        
        // Performance optimizations
        this.lastUpdate = Date.now();
        this.lastBoostConsume = 0;
        this.boostConsumeInterval = 500; // Consume character mỗi 500ms khi boost
        this.lastCollisionCheck = 0;
        this.collisionCheckInterval = 50; // Check collision mỗi 50ms
    }
    
    initializeSegments() {
        // Create initial segments
        for (let i = 0; i < CONSTANTS.INITIAL_LENGTH; i++) {
            this.segments.push({
                x: this.x - i * CONSTANTS.SEGMENT_SPACING,
                y: this.y
            });
        }
    }
    
    update(deltaTime) {
        if (!this.isAlive) return;
        
        const now = Date.now();
        
        // Update speed based on boosting
        this.speed = this.isBoosting ? CONSTANTS.BOOST_SPEED : CONSTANTS.SNAKE_SPEED;
        
        // Calculate movement
        const moveDistance = this.speed * deltaTime;
        this.x += Math.cos(this.direction) * moveDistance;
        this.y += Math.sin(this.direction) * moveDistance;
        
        // World boundaries - die if hitting boundaries
        if (this.x < 0 || this.x > CONSTANTS.WORLD_WIDTH || 
            this.y < 0 || this.y > CONSTANTS.WORLD_HEIGHT) {
            this.isAlive = false;
            return;
        }
        
        // Fixed segment update - segments follow the actual path
        if (this.segments.length > 0) {
            // Update head position
            this.segments[0].x = this.x;
            this.segments[0].y = this.y;
            
            // Update body segments to follow the path
            for (let i = 1; i < this.segments.length; i++) {
                const segment = this.segments[i];
                const prevSegment = this.segments[i - 1];
                
                // Calculate direction from previous segment to current
                const dx = prevSegment.x - segment.x;
                const dy = prevSegment.y - segment.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                // If segments are too far apart, move current segment towards previous
                if (distance > CONSTANTS.SEGMENT_SPACING) {
                    const moveRatio = Math.min((distance - CONSTANTS.SEGMENT_SPACING) / distance, 1);
                    segment.x += dx * moveRatio;
                    segment.y += dy * moveRatio;
                }
                // If segments are too close, move current segment away from previous
                else if (distance < CONSTANTS.SEGMENT_SPACING && distance > 0) {
                    const moveRatio = Math.min((CONSTANTS.SEGMENT_SPACING - distance) / distance, 1);
                    segment.x -= dx * moveRatio;
                    segment.y -= dy * moveRatio;
                }
            }
        }
        
        // Handle boosting - consume eaten characters with timer
        if (this.isBoosting && this.eatenCharacters.length > 0) {
            if (now - this.lastBoostConsume > this.boostConsumeInterval) {
                this.consumeCharacter();
                this.lastBoostConsume = now;
            }
        }
        
        // Optimized collision check with reduced frequency
        if (this.segments.length > 20 && now - this.lastCollisionCheck > this.collisionCheckInterval) {
            this.checkSelfCollision();
            this.lastCollisionCheck = now;
        }
        
        this.lastUpdate = now;
    }
    
    consumeCharacter() {
        if (this.eatenCharacters.length === 0) return;
        
        // Remove last eaten character
        const removedChar = this.eatenCharacters.pop();
        
        // Update letter counts
        if (CONSTANTS.TARGET_LETTERS.includes(removedChar)) {
            if (this.letterCounts[removedChar] > 0) {
                this.letterCounts[removedChar]--;
            }
        }
        
        // Remove a segment if snake is longer than initial length
        if (this.segments.length > CONSTANTS.INITIAL_LENGTH) {
            this.segments.pop();
            this.length = this.segments.length;
        }
    }
    
    eatFood(food) {
        // Add segment to tail
        const tail = this.segments[this.segments.length - 1];
        const newSegment = {
            x: tail.x,
            y: tail.y
        };
        this.segments.push(newSegment);
        this.length = this.segments.length;
        
        // Handle CBJS characters
        if (CONSTANTS.TARGET_LETTERS.includes(food.char)) {
            this.eatenCharacters.push(food.char);
            this.letterCounts[food.char]++;
            
        } else {
            this.eatenCharacters.push(food.char);
        }
    }
    
    checkSelfCollision() {
        const head = this.segments[0];
        const headX = head.x;
        const headY = head.y;
        const collisionThreshold = CONSTANTS.SEGMENT_SIZE * 0.8;
        const collisionThresholdSquared = collisionThreshold * collisionThreshold;
        
        // Check collision with body (skip first few segments)
        for (let i = 10; i < this.segments.length; i++) {
            const segment = this.segments[i];
            const dx = headX - segment.x;
            const dy = headY - segment.y;
            const distanceSquared = dx * dx + dy * dy;
            
            if (distanceSquared < collisionThresholdSquared) {
                this.isAlive = false;
                return true;
            }
        }
        
        return false;
    }
    
    setDirection(direction) {
        this.direction = direction;
    }
    
    setBoosting(boosting) {
        this.isBoosting = boosting;
    }
    
    // Get data for client
    getClientData() { 
        return {
            id: this.id,
            username: this.username,
            x: this.x,
            y: this.y,
            direction: this.direction,
            segments: this.segments,
            length: this.length,
            isAlive: this.isAlive,
            isBoosting: this.isBoosting,
            color: this.color,
            eatenCharacters: this.eatenCharacters,
            letterCounts: this.letterCounts
        };
    }
}

module.exports = Snake; 