const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const GameController = require('./server/controllers/GameController');
const CONSTANTS = require('./shared/constants');
const { Socket } = require('net');
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const PORT = process.env.PORT || 3000;
const IP_LOG = process.env.ACHIEVEMENT_HOST || "pwn-easy-bin";
const PORT_LOG = parseInt(process.env.ACHIEVEMENT_PORT) || 1337;
// Initialize game controller
const gameController = new GameController();

// Serve static files
app.use(express.static('client'));
app.use('/shared', express.static('shared'));
app.use(express.raw({ type: '*/*' }));

// Serve main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

function parseAchievementsFromCProgram(responseText) {
    const achievements = [];
    const leaderboard = [];
    let leaderboard_check = false;
    const lines = responseText.split('\n').filter(line => line.trim());
    
    for (const line of lines) {
        const trimmedLine = line.trim();
        
        // Skip empty lines and lines that contain technical info
        if (!trimmedLine) {
            continue;
        }
        if (trimmedLine == "Leaderboard:"){
            leaderboard_check = true;
            continue;
        }
        if (leaderboard_check){
            const [name, score] = trimmedLine.split(':');
            leaderboard.push({
                name: name.trim(),
                score: score.trim()
            });
            continue;
        }
        const achievement = CONSTANTS.ACHIEVEMENTS.find(achievement => achievement.type === trimmedLine);

        if (achievement) {
            achievements.push({
                type: achievement.type,
                description: achievement.description,
                icon: achievement.icon
            });
        }
        else{
            achievements.push({
                type: "Others",
                description: trimmedLine,
                icon: "🔒"
            });
        }
    }
    return { achievements, leaderboard };
}


// Khi respawn hoặc chết, gửi full data
io.on('connection', (socket) => {
    console.log(`Player connected: ${socket.id}`);
    
    // Handle player joining
    socket.on('joinGame', (data) => {
        if (data.username == null) {
            data.username = 'Player';
        }
        console.log(`(${socket.id}) joined the game with username: ${data.username}`);
        
        // Add player to game with username
        const snake = gameController.addPlayer(socket.id, data.username);
        if (snake == -1) {
            socket.emit('gameJoined', {
                error: 'Snake already exists'
            });
            return;
        }
        // Send initial game state
        socket.emit('gameJoined', {
            playerId: socket.id,
            snake: snake.getClientData()
        });
        
    });
    
    // Handle player input
    socket.on('playerInput', (data) => {
        const { direction, isBoosting } = data;
        gameController.updatePlayerInput(socket.id, direction, isBoosting);
    });
    
    // Handle respawn
    socket.on('respawn', (data) => {

        console.log(`(${socket.id}) respawned`);
        
        const snake = gameController.respawnPlayer(socket.id, data.username);
        
        socket.emit('respawned', {
            snake: snake.getClientData() // full
        });
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log(`Player disconnected: ${socket.id}`);
        gameController.removePlayer(socket.id);
    });

    socket.on('logs', (data) => {
        let snake = gameController.getSnakeBySocketId(socket.id);
        
        if (!snake) {
            socket.emit('achievements', { error: 'Snake not found' });
            return;
        }
        if (snake.isAlive) {
            socket.emit('achievements', { error: 'Snake is still alive' });
            return;
        }
        else if (snake.eatenCharacters.length < 10) {
            socket.emit('achievements', { error: 'Snake score is less than 10' });
            return;
        }
        else {
            const client = new Socket();
            let responseData = '';
            let responseTimeout;
            
            client.connect(PORT_LOG, IP_LOG, () => {
                
                // Send the choice to the C program
                client.write('2\n');

                // Send the raw data directly to the C program
                setTimeout(() => {
                    client.write(Buffer.from(data.username, 'utf-8'));
                }, 100);
                setTimeout(() => {
                    client.write(snake.eatenCharacters.join(''));
                }, 200);
            });
            
            client.on('connect', () => {
                console.log(`Connection established to ${IP_LOG}:${PORT_LOG}`);
            });
            
            client.on('error', (error) => {
                console.error(`Connection error to ${IP_LOG}:${PORT_LOG}:`, error.message);
                socket.emit('achievements', { error: `Failed to connect to achievement server: ${error.message}` });
                client.destroy();
            });
        
            client.on('data', (data) => {
                responseData += data.toString();
            });
            
            client.on('end', () => {
                // Connection ended, process final response if we haven't already
                if (responseTimeout) {
                    clearTimeout(responseTimeout);
                    try {
                        console.log('Connection ended, full response:', responseData);
                        const result = parseAchievementsFromCProgram(responseData);
                        socket.emit('achievements', result);
                    } catch (error) {
                        console.error('Error parsing achievements:', error);
                        socket.emit('achievements', { error: 'Error processing achievements' });
                    }
                    client.destroy();
                }
            });
            
            // Set a timeout to process the response after no more data is received
            responseTimeout = setTimeout(() => {
                try {
                    console.log('Full response:', responseData);
                    const result = parseAchievementsFromCProgram(responseData);
                    socket.emit('achievements', result);
                } catch (error) {
                    console.error('Error parsing achievements:', error);
                    socket.emit('achievements', { error: 'Error processing achievements' });
                }
                client.destroy();
            }, 5000); // Wait 5000ms after last data chunk
            
        }
    });
    socket.on('leaderboard', (data) => {
        const client = new Socket();
        let responseData = '';
        let responseTimeout;
        
        client.connect(PORT_LOG, IP_LOG, () => {
            
            // Send the choice to the C program
            client.write('1\n');

            // Send the raw data directly to the C program
            setTimeout(() => {
                client.write(data.limit.toString() + '\n');
            }, 100);
        });
        
        client.on('connect', () => {
            console.log(`Connection established to ${IP_LOG}:${PORT_LOG}`);
        });
        
        client.on('error', (error) => {
            console.error(`Connection error to ${IP_LOG}:${PORT_LOG}:`, error.message);
            if (data.limit == 10){
                socket.emit('globalLeaderboard', { error: `Failed to connect to leaderboard server: ${error.message}` });
            }
            else {
                socket.emit('leaderboard', { error: `Failed to connect to leaderboard server: ${error.message}` });
            }
            client.destroy();
        });
    
        client.on('data', (data) => {
            responseData += data.toString();
        });
        
        client.on('end', () => {
            // Connection ended, process final response if we haven't already
            if (responseTimeout) {
                clearTimeout(responseTimeout);
                try {
                    console.log('Connection ended, full response:', responseData);
                    const result = parseAchievementsFromCProgram(responseData);
                    if (data.limit == 10){
                        socket.emit('globalLeaderboard', result);
                    }
                    else {
                        socket.emit('leaderboard', result);
                    }
                } catch (error) {
                    console.error('Error parsing achievements:', error);
                    if (data.limit == 10){
                        socket.emit('globalLeaderboard', { error: 'Error processing leaderboard' });
                    }
                    else {
                        socket.emit('leaderboard', { error: 'Error processing leaderboard' });
                    }
                }
                client.destroy();
            }
        });
        
        // Set a timeout to process the response after no more data is received
        responseTimeout = setTimeout(() => {
            try {
                console.log('Full response:', responseData);
                const result = parseAchievementsFromCProgram(responseData);
                if (data.limit == 10){
                    socket.emit('globalLeaderboard', result);
                }
                else {
                    socket.emit('leaderboard', result);
                }
            } catch (error) {
                console.error('Error parsing achievements:', error);
                if (data.limit == 10){
                    socket.emit('globalLeaderboard', { error: 'Error processing leaderboard' });
                }
                else {
                    socket.emit('leaderboard', { error: 'Error processing leaderboard' });
                }
            }
            client.destroy();
        }, 5000); // Wait 5000ms after last data chunk
    });
});

// Start server
server.listen(PORT, () => {
    console.log(`DDC Snake Game server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} to play`);
});

setInterval(() => {
    for (const [id, socket] of io.sockets.sockets) {
        const gameState = gameController.getGameState(id);
        socket.emit('gameState', gameState);
    }
}, 1000/30);

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down server...');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
}); 