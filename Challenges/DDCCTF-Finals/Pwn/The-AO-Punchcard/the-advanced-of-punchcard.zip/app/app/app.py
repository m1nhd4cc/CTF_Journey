from flask import Flask, render_template, request, jsonify, send_file
import os
import numpy as np
from PIL import Image, ImageDraw
import json
import base64
import socket
import io
import time

# Get punchcard service connection info from environment
PUNCHCARD_HOST = os.getenv('PUNCHCARD_HOST', 'pwn-medium-bin')
PUNCHCARD_PORT = int(os.getenv('PUNCHCARD_PORT', '1338'))

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp', 'tiff'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def create_visual_punch_card(punch_data):
    """
    Create a visual representation of the punch card using template.png
    """
    try:
        # Load the template image
        template_img = Image.open('templates/template.png')
        
        # Convert RGBA to RGB if needed
        if template_img.mode == 'RGBA':
            rgb_img = Image.new('RGB', template_img.size, (255, 255, 255))
            rgb_img.paste(template_img, mask=template_img.split()[-1])
            template_img = rgb_img
        
        # Create a copy to work with
        img = template_img.copy()
        draw = ImageDraw.Draw(img)
        
        # Exact positioning based on user analysis
        # Column positions: first column at x=23, second at x=33, spacing = 10px
        first_col_x = 27
        col_spacing = 9
        
        row_0_y = 26 #72   # Row 12 (index 0)
        row_spacing = 26.7
        
        # Hole dimensions
        hole_width = 6
        hole_height = 12
        
        # Row Y positions mapping (row index -> y position)
        row_y_positions = {
            0: row_0_y,      # Row 12
            1: row_0_y + row_spacing,      # Row 11
            2: row_0_y + 2 * row_spacing,       # Row 0
            3: row_0_y + 3 * row_spacing,      # Row 1
            4: row_0_y + 4 * row_spacing,  # Row 2
            5: row_0_y + 5 * row_spacing,  # Row 3
            6: row_0_y + 6 * row_spacing,  # Row 4
            7: row_0_y + 7 * row_spacing,  # Row 5
            8: row_0_y + 8 * row_spacing,  # Row 6
            9: row_0_y + 9 * row_spacing,  # Row 7
            10: row_0_y + 10 * row_spacing, # Row 8
            11: row_0_y + 11 * row_spacing, # Row 9
        }
        
        for col, punched_rows in punch_data.items():
            if isinstance(col, int) and 1 <= col <= 80:
                # Calculate column position: first column (col=1) at x=23, then +10px for each column
                col_x = first_col_x + (col - 1) * col_spacing
                
                for row in punched_rows:
                    if 0 <= row < 12 and row in row_y_positions:
                        # Get exact row position
                        row_y = row_y_positions[row]
                        
                        # Calculate hole boundaries (centered on position)
                        x1 = int(col_x - hole_width // 2)
                        y1 = int(row_y - hole_height // 2)
                        x2 = int(col_x + hole_width // 2)
                        y2 = int(row_y + hole_height // 2)
                        # print(f"position x1 {x1} y1 {y1} x2 {x2} y2 {y2}")
                        # Draw WHITE rectangle for punch hole (creates visible holes)
                        draw.rectangle([x1, y1, x2, y2], fill='white', outline='black')
                        
                        # Also draw a black border around the hole to make it more visible
                        # draw.rectangle([x1-1, y1-1, x2+1, y2+1], fill=None, outline='black')
        
        return img
        
    except Exception as e:
        print(f"Error using template: {e}")
        return 0
    
def read_raw_punch_data(image_path):
    """
    Read raw punch card data from image using exact positioning
    Returns: dict in format {column: [list of punched rows]}
    """
    try:
        # Load and preprocess image
        img = Image.open(image_path)
        
        # Convert to RGB if needed
        if img.mode == 'RGBA':
            rgb_img = Image.new('RGB', img.size, (255, 255, 255))
            rgb_img.paste(img, mask=img.split()[-1])
            img = rgb_img
        
        # Convert to grayscale for hole detection
        gray = img.convert('L')
        arr = np.array(gray)
        
        # Use exact positioning from create_visual_punch_card
        punch_data = detect_holes_with_exact_positioning(arr)
       
        return {
            'success': True,
            'punch_data': punch_data,
            'image_shape': arr.shape
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

def detect_holes_with_exact_positioning(image_array):
    """
    Detect punch holes using exact positioning from create_visual_punch_card
    """
    punch_data = {}
    
    # Same positioning parameters as create_visual_punch_card
    first_col_x = 27
    col_spacing = 9
    row_0_y = 26
    row_spacing = 26.7
    
    # Hole dimensions for detection area
    hole_width = 6
    hole_height = 12
    
    # Row Y positions mapping (same as create_visual_punch_card)
    row_y_positions = {
        0: row_0_y,                          # Row 12
        1: row_0_y + row_spacing,            # Row 11
        2: row_0_y + 2 * row_spacing,        # Row 0
        3: row_0_y + 3 * row_spacing,        # Row 1
        4: row_0_y + 4 * row_spacing,        # Row 2
        5: row_0_y + 5 * row_spacing,        # Row 3
        6: row_0_y + 6 * row_spacing,        # Row 4
        7: row_0_y + 7 * row_spacing,        # Row 5
        8: row_0_y + 8 * row_spacing,        # Row 6
        9: row_0_y + 9 * row_spacing,        # Row 7
        10: row_0_y + 10 * row_spacing,      # Row 8
        11: row_0_y + 11 * row_spacing,      # Row 9
    }
    
    # Check each column (1-80)
    for col in range(1, 81):
        # Calculate column position
        col_x = first_col_x + (col - 1) * col_spacing
        
        # Check each row (0-11)
        for row_idx in range(12):
            if row_idx in row_y_positions:
                row_y = row_y_positions[row_idx]
                
                # Define detection area around expected hole position
                x1 = int(col_x - hole_width // 2)
                y1 = int(row_y - hole_height // 2)
                x2 = int(col_x + hole_width // 2)
                y2 = int(row_y + hole_height // 2)
                
                # Ensure coordinates are within image bounds
                height, width = image_array.shape
                x1 = max(0, min(x1, width - 1))
                y1 = max(0, min(y1, height - 1))
                x2 = max(0, min(x2, width - 1))
                y2 = max(0, min(y2, height - 1))
                
                if x2 > x1 and y2 > y1:
                    # Extract the region of interest
                    roi = image_array[y1:y2, x1:x2]
                    
                    # Check if this region contains a hole (dark pixels)
                    if is_hole_present(roi):
                        if col not in punch_data:
                            punch_data[col] = []
                        punch_data[col].append(row_idx)
    
    # Sort rows within each column
    for col in punch_data:
        punch_data[col].sort()
    
    return punch_data

def is_hole_present(roi):
    """
    Determine if a region of interest contains a punch hole
    """
    if roi.size == 0:
        return False
    
    # For our punch cards, holes are white (255) with black borders (0)
    # We need to be more precise to avoid false positives
    
    # Count pixels in different ranges
    white_pixels = np.sum(roi >= 240)   # Very bright pixels (white holes)
    black_pixels = np.sum(roi <= 30)    # Very dark pixels (black borders)
    gray_pixels = np.sum((roi > 30) & (roi < 240))  # Gray/intermediate pixels
    total_pixels = roi.size
    
    white_percentage = white_pixels / total_pixels
    black_percentage = black_pixels / total_pixels
    gray_percentage = gray_pixels / total_pixels
    
    # More strict criteria for hole detection:
    # 1. Must have significant white area (the actual hole)
    # 2. Must have some black borders
    # 3. Should not be mostly gray (which indicates template background)
    
    # Primary detection: Clear white hole with black borders
    if white_percentage > 0.5 and black_percentage > 0.15 and gray_percentage < 0.4:
        return True
    
    # Secondary detection: Very high contrast indicating a clear hole
    if roi.std() > 120 and white_percentage > 0.4:
        return True
    
    # Check for the specific pattern: center should be whiter than edges
    if roi.shape[0] >= 4 and roi.shape[1] >= 4:
        # Get center region (inner 50% of the ROI)
        h, w = roi.shape
        center_h_start, center_h_end = h//4, 3*h//4
        center_w_start, center_w_end = w//4, 3*w//4
        
        center = roi[center_h_start:center_h_end, center_w_start:center_w_end]
        
        # Get edge pixels (border of ROI)
        edges = np.concatenate([
            roi[0, :].flatten(),      # top edge
            roi[-1, :].flatten(),     # bottom edge
            roi[1:-1, 0].flatten(),   # left edge (excluding corners)
            roi[1:-1, -1].flatten()   # right edge (excluding corners)
        ])
        
        if center.size > 0 and edges.size > 0:
            center_avg = np.mean(center)
            edge_avg = np.mean(edges)
            
            # Center should be significantly brighter than edges
            if center_avg > edge_avg + 100 and center_avg > 200:
                return True
    
    return False

    
# Initialize processor


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/create_punch_card', methods=['POST'])
def create_punch_card():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        card_type = data.get('card_type', 'STANDARD')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        # Send request to punchcard.c service via socket
        try:
            # Create socket connection
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)  # 10 second timeout
            sock.connect((PUNCHCARD_HOST, PUNCHCARD_PORT))
             
            if card_type == 'STANDARD':
                request_data = b"create|STANDARD|" + text.encode('utf-8')
            elif card_type == 'IBM SYSTEM 360':
                request_data = b"create|IBM SYSTEM 360|" + text.encode('utf-8')
            # Developing uncompleted feature
            elif card_type == 'BASE64':
                # temporary use standard card
                request_data = b"create|STANDARD|" + base64.b64decode(text)
            else:
                return jsonify({'error': 'Invalid card type'}), 400
            
            # Send data
            sock.send(request_data)
            sock.shutdown(socket.SHUT_WR)  # Signal end of data
            
            # Receive response
            response_data = b""
            while True:
                chunk = sock.recv(8192)
                if not chunk:
                    break
                response_data += chunk
            try:
                # Parse JSON response from C program
                response_str = response_data.decode('utf-8').strip()
                result = json.loads(response_str)
                print(response_data)
            except json.JSONDecodeError as e:
                return jsonify({'error': f'Invalid JSON response: {str(e)} - Output: {response_data}'}), 500
            
            if not result.get('success', False):
                return jsonify({'error': result.get('error', 'Unknown error from C service')}), 500
            
            punch_data = result.get('punch_data', {})
            
            # Convert string keys to integers for punch_data
            punch_data_int = {}
            for col_str, rows in punch_data.items():
                punch_data_int[int(col_str)] = rows
            
            # Create visual punch card using template
            visual_card = create_visual_punch_card(punch_data_int)
            
            if visual_card and visual_card != 0:
                # Save to bytes
                img_io = io.BytesIO()
                visual_card.save(img_io, 'PNG')
                img_io.seek(0)
                
                # Save the image to a temporary file for download
                timestamp = str(int(time.time()))
                filename = f"punch_card_{timestamp}.png"
                temp_path = os.path.join('temp', filename)
                
                # Ensure temp directory exists
                os.makedirs('temp', exist_ok=True)
                
                # Save the image file
                visual_card.save(temp_path)
                
                # Encode as base64 for JSON response
                img_base64 = base64.b64encode(img_io.getvalue()).decode()
                
                return jsonify({
                    'success': True,
                    'text': text,
                    'card_type': card_type,
                    'visual_card': f'data:image/png;base64,{img_base64}',
                    'download_url': f'/download_punch_card/{filename}'
                })
            else:
                return jsonify({
                    'success': False,
                    'text': text,
                    'card_type': card_type,
                    'error': 'Could not create visual card'
                })
                
        except socket.error as e:
            return jsonify({'error': f'Connection to punchcard service failed: {str(e)}'}), 500
        except json.JSONDecodeError as e:
            return jsonify({'error': f'Invalid response from punchcard service: {str(e)}'}), 500
        except Exception as e:
            return jsonify({'error': f'Service communication error: {str(e)}'}), 500
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download_punch_card/<filename>')
def download_punch_card(filename):
    """Download the created punch card image"""
    try:
        temp_path = os.path.join('temp', filename)
        
        if not os.path.exists(temp_path):
            return "File not found", 404
        
        # Create a safe filename for download
        safe_filename = f"punch_card_{filename.split('_')[-1]}"
        
        return send_file(
            temp_path, 
            mimetype='image/png',
            as_attachment=True,
            download_name=safe_filename
        )
        
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/read_punch_card', methods=['POST'])
def read_punch_card():
    """Read raw punch card data from uploaded image and send to C program via socket"""
    try:
        # Get card type from form data
        card_type = request.form.get('card_type', 'STANDARD')
        
        # Check if image file is provided
        if 'image' in request.files:
            # Save uploaded file temporarily
            file = request.files['image']
            if file.filename == '':
                return jsonify({'error': 'No file selected'})
            
            image_path = 'punchcard_image_' + str(int(time.time())) + '.png'
            file.save(image_path)
        
        # Read punch card data
        result = read_raw_punch_data(image_path)
        
        if result['success']:
            punch_data = result['punch_data']
            
            # For both STANDARD and IBM SYSTEM 360, send JSON format
            data_to_send = json.dumps(punch_data)
            
            # Send data to C program via socket
            try:
                # Create socket connection
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)  # 10 second timeout
                sock.connect((PUNCHCARD_HOST, PUNCHCARD_PORT))
                
                # Format request: "read|card_type|data"
                request_data = f"read|{card_type}|{data_to_send}"
                
                print(f'Request data: {request_data}')
                # Send data
                sock.send(request_data.encode('utf-8'))
                sock.shutdown(socket.SHUT_WR)  # Signal end of data
                
                # Receive response
                response_data = b""
                while True:
                    chunk = sock.recv(4096)
                    if not chunk:
                        break
                    response_data += chunk
                
                sock.close()
                
                # Parse response from C program
                try:
                    output = response_data.decode('utf-8').strip()
                except Exception as e:
                    return jsonify({'error': f"Error decoding response: {str(e)} - Output: {response_data}"})
                
            except socket.error as e:
                return jsonify({'error': f"Socket connection error: {str(e)}"})
            except Exception as e:
                return jsonify({'error': f"Communication error: {str(e)}"})
            
            # Clean up temporary file if created
            if os.path.exists(image_path):
                os.remove(image_path)
            
            return jsonify({
                'success': True,
                'card_type': card_type,    
                'output': output,
                'binary_format': card_type.upper() == 'IBM SYSTEM 360'
            })
        else:
            return jsonify(result)
            
    except Exception as e:
        return jsonify({'error': f'Processing error: {str(e)}'})

if __name__ == '__main__':
    # Start the cleanup scheduler
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True) 