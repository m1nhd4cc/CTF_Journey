## Files Provided

2 files:

- `./public/hard` - The binary file for analysis
- `full.pcapng` - Network capture file

Download from these links (password: `infected`)

- https://drive.google.com/file/d/1i7EY9km-0DO_7tY24zLjNrIVbva9Ww9G/view?usp=sharing
- https://www.fshare.vn/file/LJOH51DI8BKP
- https://file.kiwi/0effb212#a8ReMDYZhBFRi363MepeSw
