#!/bin/sh

cd /home/user
while true
do
	./chall
	sleep 1
done