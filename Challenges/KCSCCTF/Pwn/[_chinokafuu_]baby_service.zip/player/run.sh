#!/bin/sh

while true
do
	./chall
done