#include <stdio.h>
#include <string.h>

struct account
{
	char *username;
	char *password;
	char *name;
	unsigned int money;
} acc;

void init()
{
	setbuf(stdin, 0);
	setbuf(stdout, 0);
	setbuf(stderr, 0);
}

void general_menu()
{
	puts("1. Login");
	puts("2. Register");
	puts("3. Exit");
	printf("> ");
}

int login()
{
	char tmp_username[0x80], tmp_password[0x80];

	if (acc.username==NULL || acc.password==NULL){
		puts("You didn't create any accounts!");
		return 0;
	}

	printf("Username: ");
	fgets(tmp_username, sizeof(tmp_username), stdin);
	printf("Password: ");
	fgets(tmp_password, sizeof(tmp_password), stdin);

	if (strcmp(tmp_username, acc.username))
	{
		puts("Invalid username!");
		return 0;
	}
	if (strcmp(tmp_password, acc.password))
	{
		puts("Invalid password!");
		return 0;
	}
	return 1;
}

int reg()
{
	char buf[0x80];

	printf("New username: ");
	fgets(buf, sizeof(buf), stdin);
	acc.username = strdup(buf);

	printf("New password: ");
	fgets(buf, sizeof(buf), stdin);
	acc.password = strdup(buf);

	printf("Your full name: ");
	fgets(buf, sizeof(buf), stdin);
	acc.name = strdup(buf);
}

void account_menu()
{
	puts("1. Deposit");
	puts("2. Withdraw");
	puts("3. Info");
	puts("4. Log out");
	printf("> ");
}

void deposit()
{
	unsigned int money;

	printf("How much?\n> ");
	scanf("%u", &money);
	getchar();
	acc.money += money;
	puts("Done!");
}

void withdraw()
{
	unsigned int money;

	printf("How much?\n> ");
	scanf("%u", &money);
	getchar();
	if (acc.money > money)
		acc.money -= money;
	puts("Done!");
}

void info()
{
	printf(acc.name);
	printf("Money: %u\n", acc.money);
}

int general_action()
{
	int choice;
	int is_done=0;
	int is_logged_in=0;

	while (!is_done && !is_logged_in)
	{
		general_menu();
		scanf("%d", &choice);
		getchar();
		switch (choice)
		{
		case 1:
			is_logged_in = login();
			break;
		case 2:
			reg();
			break;
		case 3:
			is_done = 1;
			break;
		default:
			puts("Invalid choice!");
		}
	}
	return is_done;
}

void account_action()
{
	int choice;
	int is_logged_out = 0;
	char feedback[0x100];

	while (!is_logged_out)
	{
		account_menu();
		scanf("%d", &choice);
		getchar();
		switch (choice)
		{
		case 1:
			deposit();
			break;
		case 2:
			withdraw();
			break;
		case 3:
			info();
			break;
		case 4:
			is_logged_out = 1;
			printf("Please leave a feedback: ");
			fgets(feedback, sizeof(feedback), stdin);
			puts("See you later!");
			break;
		default:
			puts("Invalid choice!");
		}
	}
}

int main()
{
	int is_done = 0;

	init();
	puts("Welcome to KCSBank");

	while (!is_done)
	{
		is_done = general_action();
		if (!is_done)
			account_action();
	}
}


