# Banking

## Description
Our club KCSC has created a new bank called KCSBank. It's still in beta but we cannot find out any bugs, please help us!

## Difficulty
Easy

## Note
Folder `docker` is used for deployment. Run `buildnstart.sh` to build and run docker
Folder `player` is used for destribution
Folder `source` contains solve script
