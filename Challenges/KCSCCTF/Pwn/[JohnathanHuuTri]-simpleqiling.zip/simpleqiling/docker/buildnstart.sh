#!/bin/sh

docker build . -t simpleqiling
docker run --restart unless-stopped -p10010:10010 -it simpleqiling
