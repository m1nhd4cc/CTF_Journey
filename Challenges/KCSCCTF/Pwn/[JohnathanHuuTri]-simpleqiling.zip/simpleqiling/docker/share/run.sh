#!/bin/sh

socat tcp-listen:10010,fork,reuseaddr exec:"/app/qi.py main"