# Petshop

## Description
Welcome to our new petshop! You can find various kinds of pet, sometimes bugs too.

## Difficulty
Medium

## Note
Folder `docker` is used for deployment. Run `buildnstart.sh` to build and run docker
Folder `player` is used for destribution
Folder `source` contains solve script
