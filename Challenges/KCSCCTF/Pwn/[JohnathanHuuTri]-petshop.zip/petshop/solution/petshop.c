#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void init(){
	setbuf(stdin, 0);
	setbuf(stdout, 0);
	setbuf(stderr, 0);
}

char *cats[] = {
	"British Shorthair",
	"Scottish Fold",
	"Siamese",
	"Asian"
};
char *dogs[] = {
	"Alaskan Malamute",
	"Corgi",
	"Golden Retriever",
	"Chihuahua",
};

struct pet{
	char *pet_type;
	char *name;
} *pet_list[8];
int pet_count = 0;

void buy(char *s){
	char type[3], name[0x400];
	int choice;

	memset(name, 0, sizeof(name));
	if (sscanf(s, "%3s %d", type, &choice) == 2) {		
		choice -= 1;

		pet_list[pet_count] = malloc(sizeof(struct pet));
		if (!strncmp(type, "cat", 3)){
			if (choice >= 4){
				puts("Invalid type of cat!");
				pet_list[pet_count] = NULL;
				return;
			}
			pet_list[pet_count]->pet_type = cats[choice];
		} else if (!strncmp(type, "dog", 3)){
			if (choice >= 4){
				puts("Invalid type of dog!");
				pet_list[pet_count] = NULL;
				return;
			}
			pet_list[pet_count]->pet_type = dogs[choice];
		} else {
			puts("We only have cats and dogs!");
			pet_list[pet_count] = NULL;
			return;
		}

		puts("Seller --> What is your pet's name?");
		printf("You    --> ");
		fgets(name, sizeof(name), stdin);
		pet_list[pet_count++]->name = strdup(name);
	}
	puts("Seller --> It's fun to have pet in your house!");
}

void sell(char *s){
	char reason[0x200];
	int idx, size;

	memset(reason, 0, sizeof(reason));
	if (sscanf(s, "%d", &idx)==1 && 0<=idx && idx<8 && pet_list[idx]) {
		pet_list[idx] = NULL;
	} else {
		puts("Seller --> There are no pet in that index!");
		return;
	}

	puts("Seller --> Nooooo, why you want to sell your pet?");
	puts("Seller --> How many characters in your reason?");
	printf("You    --> ");
	if (scanf("%d", &size)==1){
		if (size<=0 || size>=0x200){
			puts("Invalid size!");
			return;
		}
	}
	getchar();
	puts("Seller --> Your reason?");
	printf("You    --> ");
	fgets(reason, size, stdin);
	puts("Seller --> That seems reasonable!");
}

void info(char *input){
	if (!strncmp(input, "cat", 3)){
		puts("In here we have:");
		for (int i=0; i<4; i++)
			printf("%d. %s\n", i+1, cats[i]);
	} else if (!strncmp(input, "dog", 3)){
		puts("In here we have:");
		for (int i=0; i<4; i++)
			printf("%d. %s\n", i+1, dogs[i]);
	} else if (!strncmp(input, "mine", 4)){
		puts("Your pets:");
		for (int i=0; i<8; i++) {
			if (pet_list[i]) {
				printf("%d. %s\n", i+1, pet_list[i]->pet_type);
				printf("Name: %s\n", pet_list[i]->name);
			}
		}
	}
}

int main(){
	char input[0x20];

	init();

	puts("Seller --> Welcome to our pet shop!\n");

	do{
		puts("Seller --> How may I help you?");
		printf("You    --> ");
		fgets(input, sizeof(input), stdin);

		if (!strncmp(input, "buy ", 4)){
			buy(&input[4]);
		} else if (!strncmp(input, "sell ", 5)){
			sell(&input[5]);
		} else if (!strncmp(input, "info ", 5)){
			info(&input[5]);
		}
		puts("");
	}while(strncmp(input, "exit", 4));
	puts("Seller --> Thank you for shopping with us!");
}