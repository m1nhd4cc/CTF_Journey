#!/bin/sh

docker build . -t petshop
docker run --rm -p10001:10001 -it petshop