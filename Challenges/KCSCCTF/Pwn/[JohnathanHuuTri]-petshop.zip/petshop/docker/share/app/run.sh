#!/bin/sh

socat tcp-listen:10001,fork,reuseaddr exec:/app/petshop 2>/dev/null