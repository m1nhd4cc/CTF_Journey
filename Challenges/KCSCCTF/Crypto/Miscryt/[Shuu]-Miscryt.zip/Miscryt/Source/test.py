from PIL import Image
import numpy as np
import galois
GF256 = galois.GF(2**8)

img = Image.open('qr_flag_rgb.png')
pixels = img.load()
width, height = img.size

print(pixels[0, 0])
print(pixels[0, 1])
print(pixels[0, 2])