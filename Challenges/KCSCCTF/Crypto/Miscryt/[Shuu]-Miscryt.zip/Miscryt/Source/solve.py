from PIL import Image
import numpy as np
import galois
GF256 = galois.GF(2**8)

img = Image.open('qr_flag_encrypt.png')
pixels = img.load()
width, height = img.size

A = GF256(np.full((3, 3), 255))
T = GF256([pixels[0, 0], pixels[0, 1], pixels[0, 2]])
M = np.subtract(T, A)

for x in range(width):
    for y in range(0,height,3):
        T = GF256([pixels[x, y], pixels[x, y+1], pixels[x, y+2]])
        A = np.subtract(T, M)
        pixels[x, y], pixels[x, y+1], pixels[x, y+2] = [tuple([int(i) for i in j]) for j in A]
        M = np.add(A, M)

img.save('qr_flag_solved.png')
