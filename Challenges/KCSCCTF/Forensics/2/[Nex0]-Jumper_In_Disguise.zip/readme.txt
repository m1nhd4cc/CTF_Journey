challenge name: Externet Inplorer

description: 
```
Lombeos, 1 người bạn của tôi nhận được 1 file được gửi nặc danh. Bằng linh tính của mình, anh ấy nghi ngờ file này là độc hại và quyết định gửi lại file cho bạn để phân tích. Liệu bạn có thể giúp anh ấy không?

File: https://mega.nz/file/YqUlRZbI#Cx_EBZ3Kf7DHiCw891zX479D1Te1ViNeLBJo9NcTq8A
```

points: 500

format: KCSC{}

Flag: KCSC{I_@m_daStomp_dat_1z_4Ppr0/\ch1n9!}

